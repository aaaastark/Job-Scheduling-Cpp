#include <stdio.h>
#include <stdlib.h>

#define Max 10
#define number 6
/*
	Author: Muhammad Allah Rakha
	Roll No: P19-00006
	Topic: Job Scheduling Problem
	Algorithm: Greedy Algorithm
	Programming Language: C
*/

// Here: We create structure of JOB. Define the name with JOB.
typedef struct JOB {
	char id[6];
	int deadline;
	int profit;
} JOB;

// Here: We declare the function type.
void initialization_order(JOB jobs[],int num);
void jobScheduling(JOB jobs[], int num);
int minimum_Value(int x, int y);
int maximum_Deadline(JOB jobs[]);
int time_Slot_Free(int time_slot[],int max_deadline);
void scheduling_Jobs(JOB jobs[],int time_slot_free[],int max_deadline,int num);
void required_Jobs(JOB jobs[],int time_slot[],int max_deadline);
void required_Profit(JOB jobs[],int time_slot[],int max_deadline);


int main(){
	// Here: We create jobs with in deadline and profit values.
	
	/*
	// Test 1:
	JOB jobs[number] = {
		{"Job1",2,30},
		{"Job2",1,200},
		{"Job3",3,70},
		{"Job4",2,900},
		{"Job5",1,100},
		{"Job6",4,400},
	};
	*/	

	/*
	// Test 2:
	JOB jobs[number] = {
		{"Job1",2,80},
		{"Job2",1,100},
		{"Job3",3,90},
		{"Job4",2,20},
		{"Job5",1,200},
		{"Job6",4,700},
	};
	*/
	
//	/*
	// Test 3:
	JOB jobs[number] = {
		{"Job1",2,60},
		{"Job2",1,100},
		{"Job3",3,20},
		{"Job4",2,40},
		{"Job5",1,20},
		{"Job6",4,800},
	};
//	*/
	
	// Here: We call the function for (Initialization Order). Two parameter (jobs array, jobs n_index). 
	initialization_order(jobs,number);
	
	// Here: We call the function for (Job Scheduling Probleam). Two parameter (jobs array, jobs n_index). 
	jobScheduling(jobs, number);
	
	return 0;
}


/*====================================================================================================*/

// Here: We use the function of (Job Scheduling Probleam). Two parameter (jobs array, jobs n_index). 
void jobScheduling(JOB jobs[], int num){
	
	// Here: We declare variable.
	int free_Time_Slot[Max];
	int deadline_Maximum = 0;
	
	
	// Here: We declare functions.
	deadline_Maximum=maximum_Deadline(jobs);
	
	time_Slot_Free(free_Time_Slot,deadline_Maximum);
	
	scheduling_Jobs(jobs,free_Time_Slot,deadline_Maximum,num);
	
	required_Jobs(jobs,free_Time_Slot,deadline_Maximum);
	
	required_Profit(jobs,free_Time_Slot,deadline_Maximum);
}

/*====================================================================================================*/



// Here: We intialize to order value of given parameters
void initialization_order(JOB jobs[],int num){
	// Here: We create temporary (JOB). For descending order.
	JOB temporary;
	
	// Ascending to Descending Order. On the base of Profit Values.
	for(int i=1;i<number;i++){
		for(int j=0;j<number-1;j++){
			if(jobs[j+1].profit > jobs[j].profit){
				temporary = jobs[j+1];
				jobs[j+1] = jobs[j];
				jobs[j] = temporary;
			}
		}
	}
	
	// Here: We print JOB all details (Job , Deadline , Profit).
	printf("%15s %15s %15s \n","Job","Deadline","Profit");
	for(int i=0; i<number; i++){
		printf("%15s %15i %15i \n",jobs[i].id,jobs[i].deadline,jobs[i].profit);
	}
}


// Here: We calculate the minimum value of given parameters
int minimum_Value(int x, int y){
	if(x<y) return x;
	if(y<x) return y;
}


// Here: We calculate the maximum value of given deadline
int maximum_Deadline(JOB jobs[]){
	int maximum=0;
	// Here: We fined the maximum deadline value in given jobs_array.
	for(int i=0; i<number; i++){
		if(jobs[i].deadline > maximum){
			maximum = jobs[i].deadline;
		}
	}
	printf("The Deadline Maximum : %d \n",maximum);
	return maximum;
}

// Here: We initialize the free time slot with value of EMPTY on given deadline
int time_Slot_Free(int time_slot[],int max_deadline){
	// Here: We initiallize the free_time_slot -1 (-1 equal to EMPTY)
	for(int i=1; i<=max_deadline; i++){
		time_slot[i] = -1;
	}
}


// Here: We calculate the filled_time_slot value of given jobs scheduling
void scheduling_Jobs(JOB jobs[],int time_slot_free[],int max_deadline,int num){
	int filled_Time_Slot = 0;	
	// Here: We fined the filled_time_slot and initial value to free_time_slot. 
	for(int i=1; i<=num; i++){
		int return_minimum = minimum_Value(max_deadline, jobs[i-1].deadline);
		while(return_minimum >= 1){
			if(time_slot_free[return_minimum] == -1){
				time_slot_free[return_minimum] = i-1;
				filled_Time_Slot++;
				break;
			}
			return_minimum--;
		}
		if(filled_Time_Slot == max_deadline){
			break;
		}
	}
	
}

// Here: We calculate and print to the required jobs of given deadline and free time slot
void required_Jobs(JOB jobs[],int time_slot[],int max_deadline){
	// Here: We print jobs. On base free_time_slot from given jobs_array. 
	printf("The Required Jobs : ");
	for(int i=1; i<=max_deadline; i++){
		printf("%s",jobs[time_slot[i]].id);
		if(i<max_deadline){
			printf("---->");
		}
	}
}

// Here: We calculate and print to the required profit of given deadline and free time slot
void required_Profit(JOB jobs[],int time_slot[],int max_deadline){
	// Here: We print profit. On base free_time_slot from given jobs_array.
	int maximum_Profit = 0;
	for(int i=1; i<=max_deadline; i++){
		maximum_Profit += jobs[time_slot[i]].profit;
	}
	printf("\nThe Required Profit : %d\n",maximum_Profit);
}









